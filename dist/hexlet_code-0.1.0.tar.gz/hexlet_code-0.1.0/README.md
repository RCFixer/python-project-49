### Hexlet tests and linter status:
[![Actions Status](https://github.com/RCFixer/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/RCFixer/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/5a4dab013a37d9772352/maintainability)](https://codeclimate.com/github/RCFixer/python-project-49/maintainability)

### Brain-Even
https://asciinema.org/a/0tXKhfFwoXurwifSObwKsv6X6

### Brain-Calc
https://asciinema.org/a/rVcGy4dzSBZSTPr4RfPlcszLQ